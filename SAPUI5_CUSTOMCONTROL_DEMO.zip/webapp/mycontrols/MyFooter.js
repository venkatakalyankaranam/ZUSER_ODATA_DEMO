sap.ui.core.Control.extend("com.kvk.ui5.customcontrol.demo.mycontrols.MyFooter", {    
metadata : {   
	properties: {
		"footerText" : ""
	},   
    aggregations: {},   
    events: {}   
       },   

       init: function() { },   
       renderer : {         
    	    render : function(oRm, oControl) {   
    	    			oRm.write('<hr></hr> <P> <b>');   
    	    			oRm.write("My Custom Footer");   
    	    			oRm.write('</b> </p> <hr/>');   
            }       			}
       
});
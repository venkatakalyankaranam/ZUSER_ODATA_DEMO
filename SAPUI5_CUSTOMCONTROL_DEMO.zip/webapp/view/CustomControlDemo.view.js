sap.ui.jsview("com.kvk.ui5.customcontrol.demo.view.CustomControlDemo", {

	/** Specifies the Controller belonging to this View. 
	 * In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	 * @memberOf com.kvk.ui5.customcontrol.demo.view.CustomControlDemo
	 */
	getControllerName: function() {
		return "com.kvk.ui5.customcontrol.demo.controller.CustomControlDemo";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	 * Since the Controller is given to this method, its event handlers can be attached right away. 
	 * @memberOf com.kvk.ui5.customcontrol.demo.view.CustomControlDemo
	 */
	createContent: function(oController) {
		 jQuery.sap.require("com.kvk.ui5.customcontrol.demo.mycontrols.MyFooter");  
		  jQuery.sap.require("sap.viz.ui5.controls.VizFrame");  
		var oMyChart = new sap.viz.ui5.controls.VizFrame("id_Chart_VizFrame",{vizType : "stacked_bar"});
		
		var oMyCustomFooter = new com.kvk.ui5.customcontrol.demo.mycontrols.MyFooter({ footerText : "Kalyans Footer Text"});
		
		var oPage = new sap.m.Page({
			title: "Custom Control Demo",
			content: [ oMyChart , oMyCustomFooter ]
		});


		return oPage;
	}

});
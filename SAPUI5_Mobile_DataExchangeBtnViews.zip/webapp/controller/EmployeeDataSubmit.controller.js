sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.kvk.ui5.dataexchange.controller.EmployeeDataSubmit", {
		
		onInit : function(){
			
			//get the emp data Model
			
			   var oEmpModel = this.getOwnerComponent().getModel("oEmpModel");
			   this.getView().setModel(oEmpModel);
			   
			//get the CountryData Model
			var oCountryDataSetModel = this.getOwnerComponent().getModel("countryDataSetModel");
			this.getView().byId("id_Country_Select").setModel(oCountryDataSetModel);
			
		},
		
		onPressSubmit: function() {
		    var oEmpNameValue = this.getView().byId("id_Input_EmpName_EmployeeDataSubmit").getValue();
		     var oEmpIDValue = this.getView().byId("id_Input_EmpID_EmployeeDataSubmit").getValue();
		     
            this.getView().getModel().setProperty("/empName" , oEmpNameValue);
            this.getView().getModel().setProperty("/empID" , oEmpIDValue);
            
            alert(this.getView().getModel().getProperty("/empName"));
            sap.ui.core.UIComponent.getRouterFor(this).navTo("EmployeeDataDisplay");
        }


	});

});
sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.kvk.ui5.mobile.ex1.helloworld.controller.HelloWorld", {

	});
});
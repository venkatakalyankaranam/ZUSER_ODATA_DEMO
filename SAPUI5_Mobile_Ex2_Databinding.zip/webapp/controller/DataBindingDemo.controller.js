sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.kvk.ui5.mobile.ex2.databinding.controller.DataBindingDemo", {

     onInit: function(){
         //model for twoway data binding
 var oModel1 = new sap.ui.model.json.JSONModel({
        firstName : "Venkatakalyan_Model1",
        lastName  : "Karanam_Model1",
        enabled   : true,
        panelHeaderText : "Data Binding Basics - Twoway data Binding - Model1"
      });
      //setting the model in the view as a default model
      this.getView().byId("id_Panel1").setModel(oModel1,"oModel1");
      
      //model for oneway binding
   var oModel2 = new sap.ui.model.json.JSONModel({
        firstName : "Venkatamahanth_Model2",
        lastName  : "Karanam_Model2",
        enabled   : true,
        panelHeaderText : "Data Binding Basics - Oneway data Binding - Model2",
        address   : {
		    street : "Maruthinagar",
		    city : "Anantapur",
		    zip : "515004",
    		country : "India"
	            }
      });
      //set the binding mode
      oModel2.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
      //there should be only one as a default model, so oModel2 is not a 
      //default model : oModel1, refered model is oModel2 with oModel2
      this.getView().byId("id_Panel2").setModel(oModel2,"oModel2"); 
      this.getView().byId("id_Panel4").setModel(oModel2,"oModel2"); 
       
      // Create a resource bundle for language specific texts
      var oResourceModel = new sap.ui.model.resource.ResourceModel({
        bundleName : "com.kvk.ui5.mobile.ex2.databinding.i18n.i18n"
      });

      // Assign the model object to the SAPUI5 core using the name "i18n"
      this.getView().byId("id_Panel3").setModel(oResourceModel, "i18n");
      
      
     },    // init method

        formatMapUrl: function(sStreet, sZip, sCity, sCountry) {
            return "https://maps.googleapis.com/maps/api/staticmap?zoom=13&size=500x300&markers="
                                + jQuery.sap.encodeURL(sStreet + ", " + sZip +  " " + sCity + ", " + sCountry);
		}
	});

});
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller,JSONModel) {
	"use strict";
	return Controller.extend("com.kvk.ui5.mobile.ex3.controller.JsonDemo", {
		
		onInit : function () {
         // set data model on view
         var oData = {
            logindata : {
               username : "",
               password : ""
            }
         };
         var oModel = new JSONModel(oData);
         this.getView().setModel(oModel);
      },
      
      _onPressLogIn : function(){
      	
      	//capture the user name and password from the model
      	var jsonModelRef = this.getView().getModel();
      	var username = jsonModelRef.getProperty("/logindata/username");
      	alert(username);
      	
      	
      }
      
	});
});
sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.kvk.routing.controller.View1", {
		
		/**
     * Called when a controller is instantiated and its View controls (if available) are already created.
     * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
     * @memberOf com.kvk.routing.controller.View1
     */
      onInit: function() {
      },
      
      onPressNextPage: function() {
        	
            sap.ui.core.UIComponent.getRouterFor(this).navTo("View2");
        }


	});
});
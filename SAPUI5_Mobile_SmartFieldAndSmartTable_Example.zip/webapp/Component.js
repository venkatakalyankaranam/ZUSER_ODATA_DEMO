jQuery.sap.require("com.kvk.smartcontrols.demo.Config");
sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"com/kvk/smartcontrols/demo/Config"
	
], function(UIComponent, Device, Config) {
	"use strict";

	return UIComponent.extend("com.kvk.smartcontrols.demo.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			jQuery.sap.require("sap.m.routing.RouteMatchedHandler");
			UIComponent.prototype.init.apply(this, arguments);

		// set the device model
			var deviceModel = new sap.ui.model.json.JSONModel({
				isTouch: sap.ui.Device.support.touch,
				isNoTouch: !sap.ui.Device.support.touch,
				isPhone: sap.ui.Device.system.phone,
				isNoPhone: !sap.ui.Device.system.phone,
				listMode: sap.ui.Device.system.phone ? "None" : "SingleSelectMaster",
				listItemType: sap.ui.Device.system.phone ? "Active" : "Inactive"
			});
			deviceModel.setDefaultBindingMode("OneWay");
			this.setModel(deviceModel, "device");


			//Create a oData Model

			var uri = Config.getServiceUrl(Config.ODATA_SERVICE_NAME);
			var oSmartControlsModel = new sap.ui.model.odata.v2.ODataModel(uri, true, Config.LOGIN.USERNAME, Config.LOGIN.PASSWORD);
			oSmartControlsModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			oSmartControlsModel.setSizeLimit(1000);
			oSmartControlsModel.setUseBatch(false);
			this.setModel(oSmartControlsModel,"oSmartControlsModel");
			
			 //Initialize the router information
            var router = this.getRouter();
            this.routeHandler = new sap.m.routing.RouteMatchedHandler(router);
            router.initialize();
		}
	});
});
jQuery.sap.require("com.kvk.smartcontrols.demo.Config");
sap.ui.define([
	"sap/ui/core/util/MockServer",
	"com/kvk/smartcontrols/demo/Config"
], function (MockServer , Config) {
	"use strict";

	return {

		init: function () {
			
			var oUriParameters = jQuery.sap.getUriParameters();

			// create
			var oMockServer = new MockServer({
				rootUri: Config.getServiceUrl()
			});

			// configure
			MockServer.config({
				autoRespond: true,
				autoRespondAfter: oUriParameters.get("serverDelay") || 1000
			});

			// simulate
			var sPath = jQuery.sap.getModulePath("com.kvk.smartcontrols.demo.localService");
			oMockServer.simulate(sPath + "/metadata.xml", sPath + "/mockdata");

			// start
			oMockServer.start();
		}
	};

});
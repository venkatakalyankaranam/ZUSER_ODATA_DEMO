jQuery.sap.declare("com.kvk.smartcontrols.demo.Config");
sap.ui.define([], function() {
    "use strict";

    return {

        LOGIN : {
            USERNAME: "XXXXXXX",
            PASSWORD: "XXXXXXX"
        },


        DEBUG: true,

        LOCAL_REMOTE_TEST: false,
        TEST_SERVER_URL: "http://10.132.139.21:8000",

        SAP_CLIENT: "220",
        SAP_LANGUAGE: "EN",
        ROOT_URI: "/sap/opu/odata/sap/",
        

        ODATA_SERVICE_NAME: "Z_SMARTCONTROLS_DEMO_SRV",

    getServiceUrl: function(service, parameter){
           

            //var url = this.ROOT_URI + service + "?sap-client=" + this.SAP_CLIENT;
        var url = this.ROOT_URI + service;
        
        //url = /sap/opu/odata/sap/Z_SMARTCONTROLS_DEMO_SRV

        if(this.LOCAL_REMOTE_TEST){
            url = this.TEST_SERVER_URL + url;
        }

        if(parameter){
            url = url + encodeURIComponent(parameter);
        }

        if(this.DEBUG){
            url = window.location.pathname.substring(0, window.location.pathname.lastIndexOf("/")) + "/localService/";
          }
        return url;
           
        }

    };
});
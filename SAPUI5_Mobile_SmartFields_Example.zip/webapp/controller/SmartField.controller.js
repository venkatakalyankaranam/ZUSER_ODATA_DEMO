sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.kvk.smartcontrols.demo.controller.SmartField", {
		
              onInit: function() {
              	
			//this.getView().bindElement("/Products('4711')");
			//Instantiate the Main Application OData Model
			this.oModel = this.getOwnerComponent().getModel("oSmartControlsModel");
			this.getView().setModel(this.oModel);
			
			this.getView().bindElement("/Products('4711')");
			
		}
		
	});
});
sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"com/kvk/ui5/mobile/splitapp/example/model/models"
], function(UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("com.kvk.ui5.mobile.splitapp.example.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			
			jQuery.sap.require("sap.m.routing.RouteMatchedHandler");
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			
			//Initialize the router information
            var router = this.getRouter();
            this.routeHandler = new sap.m.routing.RouteMatchedHandler(router);
            router.initialize();
		}
	});
});
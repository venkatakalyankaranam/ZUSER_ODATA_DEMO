sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"com/kvk/training/demo/table/model/models"
], function(UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("com.kvk.training.demo.table.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			
            
            
			
						//initialize the router
		    var router = this.getRouter();
            this.routeHandler = new sap.m.routing.RouteMatchedHandler(router);
            router.initialize();
		},
		 _showDialog: function(state, title, msg, router, path){

            var oBundle = this.getModel("i18n").getResourceBundle();
            var title = oBundle.getText(title);
            var msg = oBundle.getText(msg);
            var btnClose = oBundle.getText("dialogButtonClose");

            var dialog = new sap.m.Dialog({
                title: title,
                type: 'Message',
                state: state,
           //     content: new sap.m.MessageStrip().setText(msg).setType(state),
                  content: new sap.m.Text().setText(msg),
                beginButton: new sap.m.Button({
                    text: btnClose,
                    press: function () {
                        dialog.close();
                        if(path){ router.navTo(path); }
                    }
                }),
                afterClose: function() {
                    dialog.destroy();
                }
            });
            dialog.open();
        }, // End of _showDialog Method
        
        _navTo: function(router, path){
        	if(path){ router.navTo(path); }
        }
	});
});
sap.ui.define([
	"sap/ui/core/mvc/Controller",
		"com/kvk/training/demo/table/model/models",
			"sap/ui/model/json/JSONModel"
], function(Controller , models , JSONModel) {
	"use strict";

	return Controller.extend("com.kvk.training.demo.table.controller.TableDemo", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.kvk.training.demo.table.view.TableDemo
		 */
			onInit: function() {
			          //get the router
		        this.oRouter = sap.ui.core.UIComponent.getRouterFor(this); 
		        //attach the event to trigger when ever this view is displayed--
		        this.oRouter.getTarget("TableDemo").attachDisplay(jQuery.proxy(this.handleRouteMatched, this));
		        //get the Model for the Table
		        var oTableData = {
										"Persons" : [   {"FirstName" : "Kalyan" , "LastName" : "Karanam"},
											             {"FirstName" : "Ravi" , "LastName" : "Yecherla"},
											             {"FirstName" : "Kedar" , "LastName" : "Nama"},
											             {"FirstName" : "XXX" , "LastName" : "LASTNAMEXXX"}
											        ]
									};
		       	var oModel = new JSONModel(oTableData);
		       	//oModel.loadData("mockdata/TableData.json");
		       	oModel.refresh();
		        //get the Table reference
		        var oTable = sap.ui.getCore().byId("id_Table_EmployeeDetails");
		        oTable.setModel(oModel);
		        oTable.bindRows("/Persons");
			},
			
			handleRouteMatched : function(oEvent){
				
			},
			
			onClickOpenAddRowFragment : function(oEvent){
				   if (!this._oTableRowFragmentDialog) {
            this._oTableRowFragmentDialog = sap.ui.jsfragment("com.kvk.training.demo.table.fragments.TableRow" , this );
            this.getView().addDependent(this._oTableRowFragmentDialog);
         }
         this._oTableRowFragmentDialog.open();
			}



	});

});
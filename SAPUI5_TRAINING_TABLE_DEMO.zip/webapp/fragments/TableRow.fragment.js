sap.ui.jsfragment("com.kvk.training.demo.table.fragments.TableRow", { 
	createContent: function(oController ) {
		
			var oLayOut = new sap.ui.layout.form.ResponsiveGridLayout("L2"); 
		
		var oFormContainerLeft = new sap.ui.layout.form.FormContainer();
        var oFormContainerRight = new sap.ui.layout.form.FormContainer();
		
		//First Name
		var oLabelFirstName = new sap.m.Label({ text : "First Name"});
		var oInputFirstName = new sap.m.Input({ value : ""});
		oInputFirstName.bindProperty("value","oModelDetails>/FirstName");
		
		var oFormElement = new sap.ui.layout.form.FormElement({
                          label : oLabelFirstName,
                          fields : [ oInputFirstName ]
                        });
                        
         oFormContainerLeft.addFormElement(oFormElement); 
         //Last Name
        var oLabelLastName = new sap.m.Label({ text : "Last Name"});
		var oInputLastName = new sap.m.Input({ value : ""});
		oInputLastName.bindProperty("value","oModelDetails>/LastName");
		
		var oFormElement = new sap.ui.layout.form.FormElement({
                          label : oLabelLastName,
                          fields : [ oInputLastName ]
                        });
                        
         oFormContainerLeft.addFormElement(oFormElement);
         
          var oForm = new sap.ui.layout.form.Form({ editable : true , layout : oLayOut });
         
         oForm.addFormContainer(oFormContainerLeft);
		 oForm.addFormContainer(oFormContainerRight);
		 
		  var oDialog = new sap.m.Dialog({
                title: "Enter Employee Details",
                
               
           //     content: new sap.m.MessageStrip().setText(msg).setType(state),
                  content: oForm,
                beginButton: new sap.m.Button({
                    text: "Add",
                    press: [oController.onPressAddTableRecord , oController]
                })
            });
           
              return oDialog;
	} 
});
sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function(JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function() {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		
		createTableModel : function(){
			var oTableData = {};
			var oModel = new JSONModel(oTableData);
		    oModel.loadData(jQuery.sap.getModulePath("com.kvk.training.demo.table.mockdata") , "/TableData.json");
			return oModel;
		}

	};
});
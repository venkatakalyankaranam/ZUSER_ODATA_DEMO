sap.ui.jsview("com.kvk.training.demo.table.view.App", {

	/** Specifies the Controller belonging to this View. 
	 * In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	 * @memberOf controller.App
	 */
	getControllerName: function() {
		return "com.kvk.training.demo.table.controller.App";
	},
	createContent: function(oController) {
	
		var app = new sap.m.App("App", {});
		return app;
	}

});
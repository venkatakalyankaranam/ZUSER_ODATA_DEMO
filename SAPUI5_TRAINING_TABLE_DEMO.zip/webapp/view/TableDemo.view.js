sap.ui.jsview("com.kvk.training.demo.table.view.TableDemo", {

	/** Specifies the Controller belonging to this View. 
	 * In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	 * @memberOf com.kvk.training.demo.table.view.TableDemo
	 */
	getControllerName: function() {
		return "com.kvk.training.demo.table.controller.TableDemo";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	 * Since the Controller is given to this method, its event handlers can be attached right away. 
	 * @memberOf com.kvk.training.demo.table.view.TableDemo
	 */
	createContent: function(oController) {


	   //create a Table
	   
	       	  var oTable = new sap.ui.table.Table("id_Table_EmployeeDetails", {
                                     	      title: "Employee Details",                                   
                                     	      visibleRowCount: 6,                                          
                                     	      selectionMode: "Single",
                                     	      toolbar : [ new sap.m.Toolbar({ content : [new sap.m.Button({ text : "Add", icon : "sap-icon://add" , press : [oController.onClickOpenAddRowFragment , oController]})]})]
    	       });
	   
	   // Create First Name column
	       	  oTable.addColumn(new sap.ui.table.Column( {
    			    label: new sap.m.Label({text: "First Name"}),
    			    template: new sap.m.Text().bindProperty("text", "FirstName") 
    			}));
	   
	   //Create Last Name Colum
	   	     oTable.addColumn(new sap.ui.table.Column( {
    			    label: new sap.m.Label({text: "Last Name"}),
    			    template: new sap.m.Text().bindProperty("text", "LastName") 
    			}));
	   
	   //Add table to page
	   
	   		var oPage = new sap.m.Page({
			title: "Employee List",
			content: [oTable]
		});
	
		return oPage;
	}

});